package com.hari.departments;

public class hrDepartment extends superDepartment {
	public String departmentName(){
		String dName  = "HR Department";
		return dName;
		
	}
	public String getTodaysWork(){
		String getTodaysWork = "Fill today's worksheet and Mark attendence";
		return getTodaysWork;
		
	}
	public String getWorkDeadline() {
		String gWD = "Complete by EOD";
		return gWD;
	}
	public String doActivity() {
		String doA = "Team lunch";
		return doA;
	}

}
