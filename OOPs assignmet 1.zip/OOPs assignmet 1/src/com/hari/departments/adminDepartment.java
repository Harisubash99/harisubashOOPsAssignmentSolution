package com.hari.departments;

 public class adminDepartment extends  superDepartment {
	 public String departmentName(){
			String dName  = "Admin Department";
			return dName;
			
		}
		public String getTodaysWork(){
			String getTodaysWork = "Complete your documents Submission";
			return getTodaysWork;
			
		}
		public String getWorkDeadline() {
			String gWD = "Complete by EOD ";
			return gWD;
		}

}
