package com.hari.departments;

public class techDepartment extends superDepartment {
	public String departmentName(){
		String dName  = "Tech Department";
		return dName;
		
	}
	public String getTodaysWork(){
		String getTodaysWork = "Complete coding of module 1";
		return getTodaysWork;
		
	}
	public String getWorkDeadline() {
		String gWD = "EOD";
		return gWD;
	}
	public String getStackInformation() {
		String gSF = "core Java";
		return gSF;
	}

}
