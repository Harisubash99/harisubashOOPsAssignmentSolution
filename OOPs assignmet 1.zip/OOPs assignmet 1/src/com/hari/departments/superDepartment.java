package com.hari.departments;

public class superDepartment {
	
	public String departmentName(){
		String dName  = "Super Department";
		return dName;
		
	}
	public String getTodaysWork(){
		String getTodaysWork = "No Work as of now";
		return getTodaysWork;
		
	}
	public String getWorkDeadline() {
		String gWD = "Nil";
		return gWD;
	}
	public String isTodayAHoliday() {
		String iTaH = "No today is not a Holiday";
		return iTaH;
	}
	

}
