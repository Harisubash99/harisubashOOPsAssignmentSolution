package com.hari.driver;

import com.hari.departments.adminDepartment;
import com.hari.departments.hrDepartment;
import com.hari.departments.superDepartment;
import com.hari.departments.techDepartment;

public class Driver {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		superDepartment sd = new superDepartment();
		System.out.println(sd.departmentName());
		System.out.println(sd.getTodaysWork());
		System.out.println(sd.getWorkDeadline());
		System.out.println(sd.isTodayAHoliday());
		System.out.println();
		
		hrDepartment a1 = new hrDepartment();
		System.out.println(a1.departmentName());
		System.out.println(a1.getTodaysWork());
		System.out.println(a1.getWorkDeadline());
		System.out.println(a1.doActivity());
		System.out.println();
		
		techDepartment td = new techDepartment();
		System.out.println(td.departmentName());
		System.out.println(td.getTodaysWork());
		System.out.println(td.getWorkDeadline());
		System.out.println(td.getStackInformation());
		System.out.println();
		
		adminDepartment a2 = new adminDepartment();
		System.out.println(a2.departmentName());
		System.out.println(a2.getTodaysWork());
		System.out.println(a2.getWorkDeadline());
		System.out.println();
		

	}

}
